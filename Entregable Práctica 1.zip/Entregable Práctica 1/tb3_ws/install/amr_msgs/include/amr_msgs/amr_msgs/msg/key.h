// generated from rosidl_generator_c/resource/idl.h.em
// with input from amr_msgs:msg/Key.idl
// generated code does not contain a copyright notice

#ifndef AMR_MSGS__MSG__KEY_H_
#define AMR_MSGS__MSG__KEY_H_

#include "amr_msgs/msg/detail/key__struct.h"
#include "amr_msgs/msg/detail/key__functions.h"
#include "amr_msgs/msg/detail/key__type_support.h"

#endif  // AMR_MSGS__MSG__KEY_H_
