// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef AMR_MSGS__MSG__KEY_HPP_
#define AMR_MSGS__MSG__KEY_HPP_

#include "amr_msgs/msg/detail/key__struct.hpp"
#include "amr_msgs/msg/detail/key__builder.hpp"
#include "amr_msgs/msg/detail/key__traits.hpp"

#endif  // AMR_MSGS__MSG__KEY_HPP_
